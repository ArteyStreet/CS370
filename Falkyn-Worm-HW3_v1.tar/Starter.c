/*
 * Starter.c
 *
 *  Created on: Feb 11, 2020
 *      Author: Falkyn Worm
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>


int main(int argc,char **argv) {
	if (argc != 2){
		fprintf(stderr, "Usage: %s <text document>.txt\n", argv[0]);
		return 1;
	}

	FILE *in = fopen(argv[1], "r");

	pid_t pid;

	int h = 0, l = 0, m = 0, o = 0, p = 0, c;

	char *str = malloc(1000);

	while ((c = fgetc(in)) != EOF){
		str[p++] = (char)c;
	}
	
	fclose(in);

	for (int i = 0; i < p - 1; i++){
		char x = str[i]; char id[BUFSIZ];
		bool high = false, low = false, math = false;
        int stat;
        
		pid = fork();
        if (pid != 0){
			printf("[Starter] Forked new process with ID %d\n", pid);
            waitpid(pid, &stat, 0);
            if (WEXITSTATUS(stat))
                low = true;
        }else{
            pid = getpid(); sprintf(id, "%d", pid);
            execlp("./LowAlpha", "./LowAlpha", &x, id, NULL); // Low
        }
		if(low){
			l++;
            printf("[Starter] Child process %d returned true.\n", pid);
			continue;
		}else 
            printf("[Starter] Child process %d returned false.\n", pid);
        
		pid = fork();
		if (pid != 0){
			printf("[Starter] Forked new process with ID %d\n", pid);
            waitpid(pid, &stat, 0);
            if (WEXITSTATUS(stat))
                high = true;
        }else{
            pid = getpid(); sprintf(id, "%d", pid);
            execlp("./HighAlpha", "./HighAlpha", &x, id, NULL); // High
        }
		if (high){
			h++;
            printf("[Starter] Child process %d returned true.\n", pid);
			continue;
		}else
            printf("[Starter] Child process %d returned false.\n", pid);

		pid = fork();
		if (pid != 0){
			printf("[Starter] Forked new process with ID %d\n", pid);
            waitpid(pid, &stat, 0);
            if (WEXITSTATUS(stat))
                math = true;
        }else{
            pid = getpid(); sprintf(id, "%d", pid);
            execlp("./Math", "./Math", &x, id, NULL); // Math
        }
		if(math) {
			m++;
            printf("[Starter] Child process %d returned true.\n", pid);
			continue;
		}else
            printf("[Starter] Child process %d returned false.\n", pid);
    
        o++;
	}
	
	printf("Low Alpha:  %d\n", l);
    printf("High alpha: %d\n", h);
    printf("Math:       %d\n", m);
    printf("Other:      %d\n", o);

    return 0;
}
