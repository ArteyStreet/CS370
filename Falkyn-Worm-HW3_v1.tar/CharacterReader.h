/*
 * CharacterReader.h
 *
 *  Created on: Feb 28, 2020
 *      Author: Falkyn Worm
 */

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

#ifndef CHARACTERREADER_H_
#define CHARACTERREADER_H_

const char* readChars(FILE* fin);

#endif /* CHARACTERREADER_H_ */

