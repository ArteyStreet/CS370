/*
 * LowAlpha.h
 *
 *  Created on: Feb 11, 2020
 *      Author: Falkyn Worm
 */

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

#ifndef LOWALPHA_H_
#define LOWALPHA_H_

bool checkLow(char c);

#endif /* LOWALPHA_H_ */
