/*
 * Math.c
 *
 *  Created on: Feb 11, 2020
 *      Author: Falkyn Worm
 */

#include "Math.h"

int main(int argc,char **argv){
    printf("[Math - pid: %s] recieved value %d.\n", argv[2], argv[1][0]);
	if (checkMath(argv[1][0])){
        printf("[Math - pid: %s] Result is true.\n", argv[2]);
		return 1;
    }
    printf("[Math - pid: %s] Result is false.\n", argv[2]);
	return 0;
}

bool checkMath(char c) {
	switch(c){
	case '+':
	case '*':
	case '-':
	case '/':
		return true;
	default:
		return false;
	}
}
