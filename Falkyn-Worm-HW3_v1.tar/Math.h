/*
 * Math.h
 *
 *  Created on: Feb 11, 2020
 *      Author: Falkyn Worm
 */

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

#ifndef MATH_H_
#define MATH_H_

bool checkMath(char c);

#endif /* MATH_H_ */
