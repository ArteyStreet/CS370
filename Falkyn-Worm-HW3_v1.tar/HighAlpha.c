/*
 * HighAlpha.c
 *
 *  Created on: Feb 11, 2020
 *      Author: Falkyn Worm
 */

#include "HighAlpha.h"

int main(int argc,char **argv){
    printf("[HighAlpha - pid: %s] recieved value %d.\n", argv[2], argv[1][0]);
	if (checkHigh(argv[1][0])){
        printf("[HighAlpha - pid: %s] Result is true.\n", argv[2]);
		return 1;
    }
    printf("[HighAlpha - pid: %s] Result is false.\n", argv[2]);
	return 0;
}

bool checkHigh(char c) {
	switch(c){
	case 'n':
	case 'o':
	case 'p':
	case 'q':
	case 'r':
	case 's':
	case 't':
	case 'u':
	case 'v':
	case 'w':
	case 'x':
	case 'y':
	case 'z':
	case 'N':
	case 'O':
	case 'P':
	case 'Q':
	case 'R':
	case 'S':
	case 'T':
	case 'U':
	case 'V':
	case 'W':
	case 'X':
	case 'Y':
	case 'Z':
		return true;
	default:
		return false;
	}
}
