/*
 * LowAlpha.c
 *
 *  Created on: Feb 11, 2020
 *      Author: Falkyn Worm
 */


#include "LowAlpha.h"

int main(int argc,char **argv){
    printf("[LowAlpha - pid: %s] recieved value %d.\n", argv[2], argv[1][0]);
	if (checkLow(argv[1][0])){
        printf("[LowAlpha - pid: %s] Result is true.\n", argv[2]);
		return 1;
    }
    printf("[LowAlpha - pid: %s] Result is false.\n", argv[2]);
	return 0;
}

bool checkLow(char c) {
	switch(c){
	case 'a':
	case 'b':
	case 'c':
	case 'd':
	case 'e':
	case 'f':
	case 'g':
	case 'h':
	case 'i':
	case 'j':
	case 'k':
	case 'l':
	case 'm':
	case 'A':
	case 'B':
	case 'C':
	case 'D':
	case 'E':
	case 'F':
	case 'G':
	case 'H':
	case 'I':
	case 'J':
	case 'K':
	case 'L':
	case 'M':
		return true;
	default:
		return false;
	}
}
