/*
 * HighAlpha.h
 *
 *  Created on: Feb 11, 2020
 *      Author: Falkyn Worm
 */

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

#ifndef HIGHALPHA_H_
#define HIGHALPHA_H_

bool checkHigh(char c);

#endif /* HIGHALPHA_H_ */
